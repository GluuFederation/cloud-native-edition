### Config-init

This sub-chart is supposed to generate or load all the configurations required by the Gluu server to run.
